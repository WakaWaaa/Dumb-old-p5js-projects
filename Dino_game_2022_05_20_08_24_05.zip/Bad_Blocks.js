class Blocks{
  constructor(){
    this.height = random(60,90);
    this.width = 55;
    this.x = width;
    this.y = height - this.height;
  }
  
  show(){
    fill('red');
    rect(this.x, this.y, this.width, this.height);
    
  }


    move(S){
     if(S > 24){
     this.x -=S/2;
      } else{
      this.x -= 12;
      }
    }


}