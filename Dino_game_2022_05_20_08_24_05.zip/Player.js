class player{
 constructor(){
  this.size = 50;
  this.x = this.size;
  this.y = height-this.size;
  this.vy = 0;
  this.gravity = 2;
  this.jumping = false;
 }
  
 jump(){this.vy = -35;}
  

collides(t){
  if((this.x) > t.x){
    if(this.x < t.x + t.width){
      if(this.y > t.y){
        if(this.y < (t.y + 50)){
        return true;
        }
      }
    }
  }
  
  if((this.x + this.size) > t.x){if(this.x + this.size < t.x + t.width){if(this.y > t.y){if(this.y < (t.y + 50)){return true;}}}}}
	
	

  
  move(){
  this.y += this.vy;
  this.vy += this.gravity;
  this.y = constrain(this.y, 0, height-this.size);
  }
 show(){
   noStroke();
   fill(0);
  rect(this.x,this.y,this.size,this.size);
  }
} 