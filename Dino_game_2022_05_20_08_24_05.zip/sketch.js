function setup() {
  createCanvas(800, 400);
  dino = new player();
  blocks = [];
}




function keyPressed(){
  if(dino.jumping == false){dino.jump();}
}

function draw() {
  if(random(1)<0.01){blocks.push(new Blocks());}
  if(random(1)<0.001){blocks.push(new Flyers());}
  background(220);
  
  if(dino.y < height-dino.size){dino.jumping = true;} 
  else{dino.jumping = false;}
    
  dino.show();
  dino.move();
  
  for(let b of blocks){
  b.move(blocks.length);
  b.show();
  
    if(dino.collides(b)){
      console.log('game over');
      console.log('score ' + blocks.length);
      noLoop();
    }
  }
}