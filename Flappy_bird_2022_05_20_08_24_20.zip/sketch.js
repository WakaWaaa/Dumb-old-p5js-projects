//Define the bird
var Bird = function(){
	this.y = height/2;
  this.x = 25;
	
  this.gravity = 0.6;
  this.lift = -10;
  this.velocity = 0;
  this.lowerBound = 0;
  
  
	this.show = function(){
    noStroke();
  	fill(255);
  	ellipse(this.x,this.y, 32,32);
  	}
  
  this.update = function(){
  	this.velocity += this.gravity;
    this.velocity*=0.99;  
  	this.y += this.velocity;
    
    if(this.y > height){
    	this.velocity = 0;
      this.y = 600;
    }
    if(this.y < 0){
    	this.velocity = 0;
      this.y = 0;
    }
  }
  
  this.up = function(){
  	this.velocity += this.lift;  
  }
  
}	
//define The Pipe
var Pipe = function(){
	this.topy = random(0,500);
  this.bottomy = this.topy + random(100,250);
  this.speed = 1;
  //Bonus points maybe??
  /*
  if(frameCount % 240 == 0 && frameCount > 100){
  	this.speed *= (5/3) ;
  	}
  if(frameCount % 120 == 0 && frameCount > 10){
  	this.speed *= 3; 
  } 
  */
  
	this.x = 400;
	
  this.show = function(){
  	fill(255);
    rect(this.x, 0, 20, this.topy);
    rect(this.x, this.bottomy, 20, height);
  }
  
  this.update = function(){
  this.x -= this.speed;
  }
  
  this.offscreen = function(){
  	if(this.x < 0){
    	return true;
    } else{
    return false;
    }
  }
  
  this.hits = function(bird){
  if(bird.y < this.topy || bird.y > this.bottomy){
  	if(bird.x > this.x && bird.x < this.x + 20){
     return true;
    }
  }
  
  
  }
}
//Setup
var bird;
var birdScore = 0;

var pipes = [];
function setup() {
  createCanvas(400, 600);
  bird = new Bird();
  pipes.push(new Pipe());
}
function draw() {
  background(220);
  
 for(var i = pipes.length - 1; i >= 0; i--){
  pipes[i].show();
  pipes[i].update();
  
   if(pipes[i].hits(bird)){
   
   lossScreen();
     fill(255);
     textSize(50);
     text('Score ' + birdScore, 100, 280);
   }
   
 if(pipes[i].x == 0){
 birdScore += pipes[i].speed;
 }
    
  if(pipes[i].offscreen()){
  	pipes.splice(i,1);
  }
 }
  
  bird.show();
  bird.update();
  
  if(frameCount % 200 == 0){
  pipes.push(new Pipe());  
  }
  
  
  
}
//Loss screen
var lossScreen = function(){
	for(var i = pipes.length - 1; i >= 0; i--){
  pipes[i].speed = 0;
  }
  bird.lift = 0;
  bird.gravity = 0;
  bird.velocity = 0;
  fill(0);
  rect(0,0,width,height);
  	
}

var newGame  = function(){
for(var i = pipes.length - 1; i >= 0; i--){
  pipes[i].speed = 1;
  }
  bird.lift = -10;
  bird.gravity = 0.6;
  bird.velocity = 0;
  fill(0);
  rect(0,0,width,height);
	birdScore = 0;
  
  
}
  


//User interaction
function keyPressed(){
	
  	bird.up();
  	
}