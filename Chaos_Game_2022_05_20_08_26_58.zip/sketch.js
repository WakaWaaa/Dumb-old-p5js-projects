let ax, ay;
let bx, by;
let cx, cy;
let dx, dy;

let x, y;

function setup() {
  createCanvas(400, 400);
  ax = random(200);
  ay = random(200);
  bx = random(200);
  by = random(200);
  cx = random(200, 400);
  cy = random(200, 400);
  dx = random(200,400);
  dy = random(200,400);
  
  x = random(width);
  y = random(height);
  
  background(0);
  strokeWeight(2);
  point(ax,ay);
  point(bx,by);
  point(cx,cy);
}

function draw() {
 
 point(x,y);
  
  let r = floor(random(4));
  if(r == 0){
     stroke('blue');
     x = lerp(x, ax, 0.5);
     y = lerp(y, ay, 0.5);
     }else if(r == 1){
      stroke('red');
     x = lerp(x, bx, 0.5);
     y = lerp(y, by, 0.5);
       }else if(r==2){
         stroke('yellow');
        x = lerp(x, cx, 0.5);
        y = lerp(y, cy, 0.5);
         }else if(r==3){
           stroke('purple');
         x = lerp(x, dx, 0.5);
        y = lerp(y, dy, 0.5);
         }
  
  
  
}